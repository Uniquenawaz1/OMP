import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertMerchantSchema, insertOfferSchema } from "@shared/schema";
import { z } from "zod";

// Check if user has exceeded the usage limit (50 records)
async function checkUsageLimit(req: Request, res: Response, next: Function) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const userId = req.user!.id;
  const recordCount = await storage.countUserRecords(userId);

  if (recordCount >= 50) {
    return res.status(403).json({ 
      message: "You have exceeded the free limit. Please subscribe or contact our sales team for further access.",
      exceeded: true,
      limit: 50,
      current: recordCount
    });
  }

  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  setupAuth(app);

  // Get record count for current user
  app.get("/api/records/count", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userId = req.user!.id;
    storage.countUserRecords(userId).then(count => {
      res.json({ count, limit: 50 });
    });
  });

  // Merchant routes
  app.get("/api/merchants", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userId = req.user!.id;
    const merchants = await storage.getMerchantsByUserId(userId);
    res.json(merchants);
  });

  app.post("/api/merchants", checkUsageLimit, async (req, res) => {
    try {
      const userId = req.user!.id;
      const merchantData = insertMerchantSchema.parse({
        ...req.body,
        userId
      });
      
      const merchant = await storage.createMerchant(merchantData);
      res.status(201).json(merchant);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid merchant data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create merchant" });
    }
  });

  // Edit merchant endpoint
  app.put("/api/merchants/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid merchant ID" });
      }

      const userId = req.user!.id;
      const merchant = await storage.getMerchant(id);
      
      if (!merchant) {
        return res.status(404).json({ message: "Merchant not found" });
      }

      if (merchant.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this merchant" });
      }

      const merchantData = insertMerchantSchema.partial().parse({
        ...req.body,
        userId
      });
      
      const updatedMerchant = await storage.updateMerchant(id, merchantData);
      res.json(updatedMerchant);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid merchant data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update merchant" });
    }
  });

  // Edit offer endpoint
  app.put("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }

      const userId = req.user!.id;
      const offer = await storage.getOffer(id);
      
      if (!offer) {
        return res.status(404).json({ message: "Offer not found" });
      }

      if (offer.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this offer" });
      }

      // Parse and validate dates
      const startDate = new Date(req.body.startDate);
      const endDate = new Date(req.body.endDate);
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }

      const offerData = {
        ...req.body,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        merchantId: parseInt(req.body.merchantId)
      };
      
      const updatedOffer = await storage.updateOffer(id, offerData);
      res.json(updatedOffer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid merchant data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update merchant" });
    }
  });

  app.delete("/api/merchants/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid merchant ID" });
      }

      const userId = req.user!.id;
      const merchant = await storage.getMerchant(id);
      
      if (!merchant) {
        return res.status(404).json({ message: "Merchant not found" });
      }

      if (merchant.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this merchant" });
      }

      await storage.deleteMerchant(id);
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete merchant" });
    }
  });

  // Offer routes
  app.get("/api/offers", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userId = req.user!.id;
    const offers = await storage.getOffersByUserId(userId);
    res.json(offers);
  });

  app.post("/api/offers", checkUsageLimit, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Verify the merchant exists and belongs to this user
      const merchantId = parseInt(req.body.merchantId);
      if (isNaN(merchantId)) {
        return res.status(400).json({ message: "Invalid merchant ID" });
      }
      
      const merchant = await storage.getMerchant(merchantId);
      if (!merchant || merchant.userId !== userId) {
        return res.status(400).json({ message: "Invalid merchant selected" });
      }

      // Parse and validate dates
      const startDate = new Date(req.body.startDate);
      const endDate = new Date(req.body.endDate);
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }
      const now = new Date();

      let status: "active" | "pending" | "expired";
      if (startDate > now) {
        status = "pending";
      } else if (endDate < now) {
        status = "expired";
      } else {
        status = "active";
      }

      const offerData = insertOfferSchema.parse({
        ...req.body,
        status,
        userId,
        merchantId
      });
      
      const offer = await storage.createOffer(offerData);
      res.status(201).json(offer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid offer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create offer" });
    }
  });

  app.put("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }

      const userId = req.user!.id;
      const offer = await storage.getOffer(id);
      
      if (!offer) {
        return res.status(404).json({ message: "Offer not found" });
      }

      if (offer.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this offer" });
      }

      // Update status if dates are changed
      let updates = req.body;
      if (req.body.startDate || req.body.endDate) {
        const startDate = new Date(req.body.startDate || offer.startDate);
        const endDate = new Date(req.body.endDate || offer.endDate);
        const now = new Date();

        let status: "active" | "pending" | "expired";
        if (startDate > now) {
          status = "pending";
        } else if (endDate < now) {
          status = "expired";
        } else {
          status = "active";
        }
        
        updates.status = status;
      }

      const offerData = insertOfferSchema.partial().parse(updates);
      const updatedOffer = await storage.updateOffer(id, offerData);
      
      res.json(updatedOffer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid offer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update offer" });
    }
  });

  app.delete("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }

      const userId = req.user!.id;
      const offer = await storage.getOffer(id);
      
      if (!offer) {
        return res.status(404).json({ message: "Offer not found" });
      }

      if (offer.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this offer" });
      }

      await storage.deleteOffer(id);
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete offer" });
    }
  });

  // Bulk upload endpoints
  app.post("/api/bulk/merchants", checkUsageLimit, async (req, res) => {
    try {
      const userId = req.user!.id;
      let merchants = req.body;
      
      // Ensure merchants is an array
      if (!Array.isArray(merchants)) {
        merchants = [merchants];
      }
      
      // Check if this would exceed the limit
      const currentCount = await storage.countUserRecords(userId);
      if (currentCount + merchants.length > 50) {
        return res.status(403).json({
          message: "This upload would exceed your limit of 50 records",
          exceeded: true,
          limit: 50,
          current: currentCount,
          wouldAdd: merchants.length
        });
      }
      
      const createdMerchants = [];
      for (const merchant of merchants) {
        const merchantData = insertMerchantSchema.parse({
          ...merchant,
          userId
        });
        
        const createdMerchant = await storage.createMerchant(merchantData);
        createdMerchants.push(createdMerchant);
      }
      
      res.status(201).json(createdMerchants);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid merchant data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to bulk create merchants" });
    }
  });
  
  app.post("/api/bulk/offers", checkUsageLimit, async (req, res) => {
    try {
      const userId = req.user!.id;
      const offers = req.body;
      
      if (!Array.isArray(offers) || offers.length === 0) {
        return res.status(400).json({ message: "Invalid offer data format. Expected an array of offers." });
      }
      
      // Check if this would exceed the limit
      const currentCount = await storage.countUserRecords(userId);
      if (currentCount + offers.length > 50) {
        return res.status(403).json({
          message: "This upload would exceed your limit of 50 records",
          exceeded: true,
          limit: 50,
          current: currentCount,
          wouldAdd: offers.length
        });
      }
      
      const createdOffers = [];
      for (const offer of offers) {
        try {
          // Verify merchant exists and belongs to this user
          const merchantId = parseInt(offer.merchantId);
          if (isNaN(merchantId)) {
            console.error(`Invalid merchant ID format: ${offer.merchantId}`);
            continue; // Skip this offer but continue processing others
          }
          
          const merchant = await storage.getMerchant(merchantId);
          if (!merchant || merchant.userId !== userId) {
            console.error(`Invalid merchant ID or doesn't belong to user: ${merchantId}`);
            continue; // Skip this offer but continue processing others
          }
          
          // Try to parse dates, default to current date if invalid
          let startDate, endDate;
          try {
            startDate = new Date(offer.startDate);
            if (isNaN(startDate.getTime())) startDate = new Date();
          } catch (e) {
            startDate = new Date();
          }
          
          try {
            endDate = new Date(offer.endDate);
            if (isNaN(endDate.getTime())) {
              // Default to 30 days from start date
              endDate = new Date(startDate);
              endDate.setDate(endDate.getDate() + 30);
            }
          } catch (e) {
            endDate = new Date(startDate);
            endDate.setDate(endDate.getDate() + 30);
          }
          
          const now = new Date();
          
          // Determine status
          let status: "active" | "pending" | "expired";
          if (startDate > now) {
            status = "pending";
          } else if (endDate < now) {
            status = "expired";
          } else {
            status = "active";
          }
          
          // Prepare the offer data with all required fields
          const offerData = {
            title: offer.title || "Untitled Offer",
            description: offer.description || "",
            offerType: offer.offerType || "discount",
            channel: (offer.channel || "online") as "online" | "offline" | "both",
            startDate,
            endDate,
            status,
            userId,
            merchantId,
            terms: offer.terms || null,
            redemptionInstructions: offer.redemptionInstructions || null,
            locations: offer.locations || null,
            image: offer.image || null
          };
          
          const createdOffer = await storage.createOffer(offerData);
          createdOffers.push(createdOffer);
        } catch (err) {
          console.error("Error processing offer:", err);
          // Continue with the next offer
        }
      }
      
      if (createdOffers.length === 0) {
        return res.status(400).json({ 
          message: "No valid offers could be processed. Please check your CSV format and try again."
        });
      }
      
      res.status(201).json(createdOffers);
    } catch (error: any) {
      console.error("Bulk offer upload error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid offer data", errors: error.errors });
      }
      res.status(500).json({ message: `Failed to bulk create offers: ${error.message}` });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
