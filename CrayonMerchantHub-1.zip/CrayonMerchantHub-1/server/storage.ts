import { users, merchants, offers, type User, type InsertUser, type Merchant, type InsertMerchant, type Offer, type InsertOffer } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Merchant methods
  getMerchant(id: number): Promise<Merchant | undefined>;
  getMerchantsByUserId(userId: number): Promise<Merchant[]>;
  createMerchant(merchant: InsertMerchant): Promise<Merchant>;
  updateMerchant(id: number, merchant: Partial<InsertMerchant>): Promise<Merchant | undefined>;
  deleteMerchant(id: number): Promise<boolean>;
  getAllMerchants(): Promise<Merchant[]>;

  // Offer methods
  getOffer(id: number): Promise<Offer | undefined>;
  getOffersByUserId(userId: number): Promise<Offer[]>;
  getOffersByMerchantId(merchantId: number): Promise<Offer[]>;
  createOffer(offer: InsertOffer): Promise<Offer>;
  updateOffer(id: number, offer: Partial<InsertOffer>): Promise<Offer | undefined>;
  deleteOffer(id: number): Promise<boolean>;
  getAllOffers(): Promise<Offer[]>;

  // Count records (for usage limit)
  countUserRecords(userId: number): Promise<number>;

  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private merchants: Map<number, Merchant>;
  private offers: Map<number, Offer>;
  sessionStore: session.SessionStore;
  currentUserId: number;
  currentMerchantId: number;
  currentOfferId: number;

  constructor() {
    this.users = new Map();
    this.merchants = new Map();
    this.offers = new Map();
    this.currentUserId = 1;
    this.currentMerchantId = 1;
    this.currentOfferId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Clear expired sessions every 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Check for existing username or email
    const existingUsername = await this.getUserByUsername(insertUser.username);
    if (existingUsername) {
      throw new Error("Username already exists");
    }
    
    const existingEmail = await this.getUserByEmail(insertUser.email);
    if (existingEmail) {
      throw new Error("Email already exists");
    }
    
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    console.log("Created user:", { ...user, password: "[REDACTED]" });
    return user;
  }

  // Merchant methods
  async getMerchant(id: number): Promise<Merchant | undefined> {
    return this.merchants.get(id);
  }

  async getMerchantsByUserId(userId: number): Promise<Merchant[]> {
    return Array.from(this.merchants.values()).filter(
      (merchant) => merchant.userId === userId,
    );
  }

  async createMerchant(insertMerchant: InsertMerchant): Promise<Merchant> {
    const id = this.currentMerchantId++;
    const merchant: Merchant = { ...insertMerchant, id };
    this.merchants.set(id, merchant);
    return merchant;
  }

  async updateMerchant(id: number, merchant: Partial<InsertMerchant>): Promise<Merchant | undefined> {
    const existingMerchant = this.merchants.get(id);
    if (!existingMerchant) return undefined;
    
    const updatedMerchant = { ...existingMerchant, ...merchant };
    this.merchants.set(id, updatedMerchant);
    return updatedMerchant;
  }

  async deleteMerchant(id: number): Promise<boolean> {
    return this.merchants.delete(id);
  }

  async getAllMerchants(): Promise<Merchant[]> {
    return Array.from(this.merchants.values());
  }

  // Offer methods
  async getOffer(id: number): Promise<Offer | undefined> {
    return this.offers.get(id);
  }

  async getOffersByUserId(userId: number): Promise<Offer[]> {
    return Array.from(this.offers.values()).filter(
      (offer) => offer.userId === userId,
    );
  }

  async getOffersByMerchantId(merchantId: number): Promise<Offer[]> {
    return Array.from(this.offers.values()).filter(
      (offer) => offer.merchantId === merchantId,
    );
  }

  async createOffer(insertOffer: InsertOffer): Promise<Offer> {
    const id = this.currentOfferId++;
    const offer: Offer = { ...insertOffer, id };
    this.offers.set(id, offer);
    return offer;
  }

  async updateOffer(id: number, offer: Partial<InsertOffer>): Promise<Offer | undefined> {
    const existingOffer = this.offers.get(id);
    if (!existingOffer) return undefined;
    
    const updatedOffer = { ...existingOffer, ...offer };
    this.offers.set(id, updatedOffer);
    return updatedOffer;
  }

  async deleteOffer(id: number): Promise<boolean> {
    return this.offers.delete(id);
  }

  async getAllOffers(): Promise<Offer[]> {
    return Array.from(this.offers.values());
  }

  // Count total records for a user (merchants + offers)
  async countUserRecords(userId: number): Promise<number> {
    const merchantCount = (await this.getMerchantsByUserId(userId)).length;
    const offerCount = (await this.getOffersByUserId(userId)).length;
    return merchantCount + offerCount;
  }
}

export const storage = new MemStorage();
