import { createContext, ReactNode, useContext, useEffect } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { insertUserSchema, User } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { signInWithGoogle, handleRedirectResult } from "@/lib/firebase";

type AuthContextType = {
  user: Omit<User, "password"> | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<Omit<User, "password">, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<Omit<User, "password">, Error, RegisterData>;
  googleLoginMutation: UseMutationResult<Omit<User, "password">, Error, void>;
};

type LoginData = {
  username: string;
  password: string;
};

const registerSchema = z.object({
  username: z.string().min(3).max(30),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(["merchant", "bank"])
});

type RegisterData = z.infer<typeof registerSchema>;

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<Omit<User, "password"> | null, Error>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/login", credentials);
      return await res.json();
    },
    onSuccess: (user: Omit<User, "password">) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Logged in successfully",
        description: `Welcome back, ${user.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegisterData) => {
      const res = await apiRequest("POST", "/api/register", data);
      return await res.json();
    },
    onSuccess: (user: Omit<User, "password">) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Registration successful",
        description: "Your account has been created!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      queryClient.invalidateQueries();
      toast({
        title: "Logged out",
        description: "You have been logged out successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const googleLoginMutation = useMutation<Omit<User, "password">, Error, void>({
    mutationFn: async () => {
      // This will redirect to Google, so we won't get a return value here
      await signInWithGoogle();
      // Since this redirects, we won't reach this code
      // Returning a dummy value to satisfy TypeScript
      return {} as Omit<User, "password">;
    },
    onError: (error: Error) => {
      toast({
        title: "Google login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle Google redirect result on page load
  useEffect(() => {
    async function checkRedirectResult() {
      try {
        console.log("Checking for Google auth redirect result...");
        const result = await handleRedirectResult();
        
        if (result) {
          console.log("Google auth redirect result found:", result);
          // User came back from Google auth, make backend call
          try {
            const res = await apiRequest("POST", "/api/auth/google", {
              email: result.email,
              displayName: result.displayName,
            });
            
            if (!res.ok) {
              const errorData = await res.json();
              throw new Error(errorData.message || "Failed to authenticate with Google");
            }
            
            // Update auth state with the user
            const user = await res.json();
            queryClient.setQueryData(["/api/user"], user);
            
            toast({
              title: "Google login successful",
              description: `Welcome, ${user.username}!`,
            });
          } catch (backendError: any) {
            console.error("Backend API error:", backendError);
            toast({
              title: "Authentication error",
              description: backendError?.message || "Failed to complete Google authentication",
              variant: "destructive",
            });
          }
        } else {
          console.log("No Google auth redirect result found");
        }
      } catch (error: any) {
        console.error("Failed to handle Google redirect:", error);
        toast({
          title: "Google login failed",
          description: error.message || "There was an error processing your Google login",
          variant: "destructive",
        });
      }
    }
    
    // Check for redirect result when component mounts
    checkRedirectResult();
  }, [toast]);

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
        googleLoginMutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
