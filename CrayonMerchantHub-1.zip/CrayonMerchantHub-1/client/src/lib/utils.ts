import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import Papa from "papaparse";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .substring(0, 2);
}

export function formatDate(date: Date) {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

export async function parseCSV(file: File): Promise<any[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.errors.length > 0) {
          reject(new Error(results.errors[0].message));
        } else {
          resolve(results.data);
        }
      },
      error: (error) => reject(error)
    });
  });
}

export function exportToCSV(data: any[], filename: string) {
  const replacer = (key: string, value: any) => value === null ? '' : value;
  const header = Object.keys(data[0]);
  let csv = data.map(row => header.map(fieldName => JSON.stringify(row[fieldName], replacer)).join(','));
  csv.unshift(header.join(','));
  const csvArray = csv.join('\r\n');

  const blob = new Blob([csvArray], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  window.URL.revokeObjectURL(url);
}

export function downloadTemplate(type: "merchants" | "offers") {
  const merchantTemplate = `name,email,phone,address,category,country,registrationNumber
Example Store,store@example.com,+1234567890,"123 Main St, City",Retail,US,REG123456
`;

  const offerTemplate = `title,description,offerType,channel,startDate,endDate,merchantId,terms,redemptionInstructions,locations
Summer Sale,20% off all items,discount,online,${new Date().toISOString().split('T')[0]},${new Date(Date.now() + 30*24*60*60*1000).toISOString().split('T')[0]},1,Terms apply,Use code SUMMER20,All locations
`;

  const content = type === "merchants" ? merchantTemplate : offerTemplate;
  const blob = new Blob([content], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${type}-template.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
}

export function getStatusColor(status: string): string {
  switch (status.toLowerCase()) {
    case "active":
      return "status-badge-active";
    case "live":
      return "status-badge-live";
    case "pending":
      return "status-badge-pending";
    case "expired":
      return "status-badge-expired";
    default:
      return "bg-gray-100 text-gray-800";
  }
}
export function downloadAsCSV(data: any[], filename: string, merchants?: any[], users?: any[]) {
  if (!data.length) return;

  // Create a copy of the data to modify
  const processedData = data.map(item => {
    const processed = { ...item };

    // Replace merchantId with merchant name if available
    if (merchants && processed.merchantId) {
      const merchant = merchants.find(m => m.id === processed.merchantId);
      if (merchant) {
        processed.merchantName = merchant.name;
        delete processed.merchantId;
      }
    }

    // Replace userId with user name if available
    if (users && processed.userId) {
      const user = users.find(u => u.id === processed.userId);
      if (user) {
        processed.userName = user.username;
        delete processed.userId;
      }
    }

    return processed;
  });

  const headers = Object.keys(processedData[0]);
  const csvArray = [
    headers.join(','),
    ...processedData.map(row => headers.map(header => row[header]).join(','))
  ].join('\n');

  const blob = new Blob([csvArray], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  window.URL.revokeObjectURL(url);
}