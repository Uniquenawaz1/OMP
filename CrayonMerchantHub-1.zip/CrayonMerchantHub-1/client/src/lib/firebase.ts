import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithRedirect, getRedirectResult } from "firebase/auth";

// Load Firebase configuration from environment variables
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// Check if we have all the required Firebase config values
const isMissingConfig = !firebaseConfig.apiKey || !firebaseConfig.projectId || !firebaseConfig.appId;
if (isMissingConfig) {
  console.warn("Firebase configuration is incomplete. Google authentication will not work properly.");
}

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Configure Google auth provider
const googleProvider = new GoogleAuthProvider();

// Add additional OAuth scopes to get user's profile and email
googleProvider.addScope('profile');
googleProvider.addScope('email');

// Set custom parameters to always show the account selection screen
// and allow any domain to use this flow
googleProvider.setCustomParameters({
  prompt: 'select_account',
  include_granted_scopes: 'true',
  access_type: 'offline',
  hd: '.repl.co' // Restrict to Replit domains
});

// Log domain for debugging
console.log("Current domain:", window.location.hostname);

export { auth, googleProvider };

// Try to handle any pending redirect result on page load
export const handleRedirectResult = async () => {
  try {
    const result = await getRedirectResult(auth);
    if (result) {
      const user = result.user;
      return {
        user,
        email: user.email || '',
        displayName: user.displayName || ''
      };
    }
    return null;
  } catch (error: any) {
    console.error("Error handling redirect result:", error);
    return null;
  }
};

// Use redirect auth instead of popup for better compatibility
export const signInWithGoogle = async () => {
  try {
    // Console logs to track execution flow
    console.log("Starting Google sign-in redirect...");

    // Check for firebaseConfig before proceeding
    if (isMissingConfig) {
      console.error("Cannot sign in with Google: Firebase configuration is incomplete");
      throw new Error("Firebase configuration is incomplete. Please contact support.");
    }

    const domain = window.location.hostname;
    console.log("Attempting Google sign-in from domain:", domain);
    await signInWithRedirect(auth, googleProvider);


    // Note: Code after this line will not execute due to the redirect
    // This function won't actually return as the page is redirected
    // The result will be handled by handleRedirectResult() when the user returns
    console.log("This log should never appear due to redirect");
    return null;
  } catch (error: any) {
    // Detailed error logging
    console.error("Error during Google sign-in redirect:", error);
    console.error("Error code:", error.code);
    console.error("Error message:", error.message);

    // Provide a more user-friendly error message
    let errorMessage = "Failed to sign in with Google. Please try again.";

    if (error.code === 'auth/unauthorized-domain') {
      errorMessage = `This website is not authorized to use Google authentication. Please add ${window.location.origin} to your Firebase Console authorized domains.`;
    } else if (error.code === 'auth/popup-closed-by-user') {
      errorMessage = "Sign-in was canceled. Please try again.";
    } else if (error.code === 'auth/network-request-failed') {
      errorMessage = "Network error. Please check your internet connection and try again.";
    }

    throw new Error(errorMessage);
  }
};