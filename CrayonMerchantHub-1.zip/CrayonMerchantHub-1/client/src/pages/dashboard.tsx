import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, Upload, BarChart3, Building2, Tag } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Link } from "wouter";
import { Merchant, Offer } from "@shared/schema";
import { CSVUploadModal } from "@/components/csv-upload-modal";
import { AddMerchantForm } from "@/components/add-merchant-form";
import { AddOfferForm } from "@/components/add-offer-form";
import { formatDate } from "@/lib/utils";

export default function Dashboard() {
  const [showAddMerchantForm, setShowAddMerchantForm] = useState(false);
  const [showAddOfferForm, setShowAddOfferForm] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  
  // Fetch merchants
  const { data: merchants = [] } = useQuery<Merchant[]>({
    queryKey: ['/api/merchants'],
  });
  
  // Fetch offers
  const { data: offers = [] } = useQuery<Offer[]>({
    queryKey: ['/api/offers'],
  });
  
  // Calculate active offers count
  const activeOffers = offers.filter(offer => offer.status === 'active' || offer.status === 'live').length;
  
  // Generate recent activities (from merchants and offers)
  const recentActivities = [
    ...merchants.map(merchant => ({
      type: 'merchant',
      id: merchant.id,
      title: `Added merchant: ${merchant.name}`,
      status: 'Success',
      date: new Date(),
    })),
    ...offers.map(offer => ({
      type: 'offer',
      id: offer.id,
      title: `Added offer: ${offer.title}`,
      status: 'Success',
      date: new Date(offer.startDate),
    })),
  ]
  .sort((a, b) => b.date.getTime() - a.date.getTime())
  .slice(0, 5);
  
  return (
    <>
      <div className="grid gap-4 md:gap-8">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                  <Building2 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Merchants</p>
                  <h3 className="text-2xl font-bold">{merchants.length}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                  <Tag className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Offers</p>
                  <h3 className="text-2xl font-bold">{offers.length}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 bg-amber-100 rounded-md p-3">
                  <BarChart3 className="h-6 w-6 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Active Offers</p>
                  <h3 className="text-2xl font-bold">{activeOffers}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div 
                  className="relative rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm flex items-center space-x-3 hover:border-gray-400 focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary cursor-pointer"
                  onClick={() => setShowAddMerchantForm(true)}
                >
                  <div className="flex-shrink-0">
                    <PlusCircle className="h-8 w-8 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="focus:outline-none">
                      <p className="text-sm font-medium text-gray-900">Add New Merchant</p>
                      <p className="text-sm text-gray-500 truncate">Create and manage merchants</p>
                    </span>
                  </div>
                </div>
                
                <div 
                  className="relative rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm flex items-center space-x-3 hover:border-gray-400 focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary cursor-pointer"
                  onClick={() => setShowAddOfferForm(true)}
                >
                  <div className="flex-shrink-0">
                    <PlusCircle className="h-8 w-8 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="focus:outline-none">
                      <p className="text-sm font-medium text-gray-900">Add New Offer</p>
                      <p className="text-sm text-gray-500 truncate">Create and manage offers</p>
                    </span>
                  </div>
                </div>
                
                <div 
                  className="relative rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm flex items-center space-x-3 hover:border-gray-400 focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary cursor-pointer"
                  onClick={() => setShowUploadModal(true)}
                >
                  <div className="flex-shrink-0">
                    <Upload className="h-8 w-8 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="focus:outline-none">
                      <p className="text-sm font-medium text-gray-900">Bulk Upload</p>
                      <p className="text-sm text-gray-500 truncate">Upload CSV files for merchants and offers</p>
                    </span>
                  </div>
                </div>
                
                <div className="relative rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm flex items-center space-x-3 hover:border-gray-400 focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary cursor-pointer">
                  <div className="flex-shrink-0">
                    <BarChart3 className="h-8 w-8 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="focus:outline-none">
                      <p className="text-sm font-medium text-gray-900">Generate Reports</p>
                      <p className="text-sm text-gray-500 truncate">View and export reports</p>
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="divide-y divide-gray-200">
                {recentActivities.length > 0 ? (
                  recentActivities.map((activity, index) => (
                    <li key={`${activity.type}-${activity.id}`} className="px-4 py-4">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-primary truncate">{activity.title}</p>
                        <div className="ml-2 flex-shrink-0 flex">
                          <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            {activity.status}
                          </p>
                        </div>
                      </div>
                      <div className="mt-2 flex justify-between">
                        <div className="flex items-center text-sm text-gray-500">
                          <div className="mt-2 flex items-center text-sm text-gray-500">
                            {formatDate(activity.date)}
                          </div>
                        </div>
                      </div>
                    </li>
                  ))
                ) : (
                  <li className="px-4 py-6 text-center text-gray-500">
                    No recent activity to display
                  </li>
                )}
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Modals */}
      <AddMerchantForm 
        open={showAddMerchantForm} 
        onOpenChange={setShowAddMerchantForm} 
      />
      
      <AddOfferForm 
        open={showAddOfferForm} 
        onOpenChange={setShowAddOfferForm} 
        merchants={merchants}
      />
      
      <CSVUploadModal
        open={showUploadModal}
        onOpenChange={setShowUploadModal}
      />
    </>
  );
}
