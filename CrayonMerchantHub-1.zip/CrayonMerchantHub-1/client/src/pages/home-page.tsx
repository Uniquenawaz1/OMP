import { useState } from 'react';
import { Navbar } from '@/components/navbar';
import Dashboard from '@/pages/dashboard';
import Merchants from '@/pages/merchants';
import Offers from '@/pages/offers';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'merchants' | 'offers'>('dashboard');
  
  // Get the record count for usage limits
  const { data: recordData } = useQuery({
    queryKey: ['/api/records/count'],
    queryFn: async () => {
      const res = await fetch('/api/records/count', { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch record count');
      return res.json();
    }
  });
  
  const recordCount = recordData?.count || 0;
  const recordLimit = recordData?.limit || 50;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
        recordCount={recordCount} 
        recordLimit={recordLimit}
      />
      
      <main className="flex-1 container mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'merchants' && <Merchants recordCount={recordCount} recordLimit={recordLimit} />}
        {activeTab === 'offers' && <Offers recordCount={recordCount} recordLimit={recordLimit} />}
      </main>
    </div>
  );
}
