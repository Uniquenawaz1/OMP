import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { PlusCircle, Upload, Trash2, Pencil, Loader2, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Offer, Merchant } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { AddOfferForm } from "@/components/add-offer-form";
import { CSVUploadModal } from "@/components/csv-upload-modal";
import { LimitExceededModal } from "@/components/limit-exceeded-modal";
import { formatDate, getStatusColor, downloadAsCSV } from "@/lib/utils";

interface OffersProps {
  recordCount: number;
  recordLimit: number;
}

export default function Offers({ recordCount, recordLimit }: OffersProps) {
  const { toast } = useToast();
  const [showAddOfferForm, setShowAddOfferForm] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [offerToDelete, setOfferToDelete] = useState<Offer | null>(null);
  
  // Fetch offers
  const { data: offers = [], isLoading, error } = useQuery<Offer[]>({
    queryKey: ['/api/offers'],
  });
  
  // Fetch merchants for dropdown
  const { data: merchants = [] } = useQuery<Merchant[]>({
    queryKey: ['/api/merchants'],
  });
  
  // Delete offer mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/offers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/records/count'] });
      toast({
        title: "Offer deleted",
        description: "The offer has been deleted successfully.",
      });
      setOfferToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete offer: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Get merchant name by ID
  const getMerchantName = (merchantId: number) => {
    const merchant = merchants.find(m => m.id === merchantId);
    return merchant ? merchant.name : "Unknown Merchant";
  };
  
  const handleAddOffer = () => {
    if (recordCount >= recordLimit) {
      setShowLimitModal(true);
    } else {
      setShowAddOfferForm(true);
    }
  };
  
  const handleDeleteOffer = (offer: Offer) => {
    setOfferToDelete(offer);
  };
  
  const confirmDelete = () => {
    if (offerToDelete) {
      deleteMutation.mutate(offerToDelete.id);
    }
  };
  
  return (
    <>
      <Card>
        <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <CardTitle>Offers</CardTitle>
            <CardDescription>Manage all your promotional offers.</CardDescription>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 mt-4 md:mt-0">
            <Button onClick={handleAddOffer}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Offer
            </Button>
            <Button variant="outline" onClick={() => setShowUploadModal(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Bulk Upload
            </Button>
            <Button 
              variant="outline" 
              onClick={() => downloadAsCSV(offers, 'offers', merchants)}
            >
              <Download className="mr-2 h-4 w-4" />
              Download CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-500">
              Error loading offers: {(error as Error).message}
            </div>
          ) : offers.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No offers found. Add your first offer to get started.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Offer Title</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Description</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Merchant</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Start Date</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">End Date</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Status</th>
                    <th className="py-3 px-4 text-right font-medium text-gray-500 text-sm">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {offers.map((offer) => (
                    <tr key={offer.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4 text-sm font-medium">{offer.title}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">
                        {offer.description.length > 40 
                          ? `${offer.description.substring(0, 40)}...` 
                          : offer.description}
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600">{getMerchantName(offer.merchantId)}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{formatDate(offer.startDate)}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{formatDate(offer.endDate)}</td>
                      <td className="py-3 px-4 text-sm">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(offer.status)}`}>
                          {offer.status.charAt(0).toUpperCase() + offer.status.slice(1)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex justify-end space-x-2">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => setOfferToEdit(offer)}
                          >
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleDeleteOffer(offer)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Add Offer Form */}
      <AddOfferForm 
        open={showAddOfferForm} 
        onOpenChange={setShowAddOfferForm} 
        merchants={merchants}
      />
      
      {/* CSV Upload Modal */}
      <CSVUploadModal
        open={showUploadModal}
        onOpenChange={setShowUploadModal}
      />
      
      {/* Limit Exceeded Modal */}
      <LimitExceededModal 
        open={showLimitModal}
        onOpenChange={setShowLimitModal}
      />
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={!!offerToDelete} onOpenChange={(open) => !open && setOfferToDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the offer "{offerToDelete?.title}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOfferToDelete(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteMutation.isPending}>
              {deleteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
