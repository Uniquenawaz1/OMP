import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { PlusCircle, Upload, Trash2, Pencil, Loader2, Wand2, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Merchant } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { AddMerchantForm } from "@/components/add-merchant-form";
import { CSVUploadModal } from "@/components/csv-upload-modal";
import { LimitExceededModal } from "@/components/limit-exceeded-modal";
import { formatDate, getStatusColor, downloadAsCSV } from "@/lib/utils"; // Import updated to include downloadAsCSV

interface MerchantsProps {
  recordCount: number;
  recordLimit: number;
}

export default function Merchants({ recordCount, recordLimit }: MerchantsProps) {
  const { toast } = useToast();
  const [showAddMerchantForm, setShowAddMerchantForm] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [merchantToDelete, setMerchantToDelete] = useState<Merchant | null>(null);
  const [merchantToEdit, setMerchantToEdit] = useState<Merchant | null>(null);
  const [showEditMerchantForm, setShowEditMerchantForm] = useState(false);

  // Fetch merchants
  const { data: merchants = [], isLoading, error } = useQuery<Merchant[]>({
    queryKey: ['/api/merchants'],
  });

  // Fetch offers to get count per merchant
  const { data: offers = [] } = useQuery<any[]>({
    queryKey: ['/api/offers'],
  });

  // Delete merchant mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/merchants/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/merchants'] });
      queryClient.invalidateQueries({ queryKey: ['/api/records/count'] });
      toast({
        title: "Merchant deleted",
        description: "The merchant has been deleted successfully.",
      });
      setMerchantToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete merchant: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Get offer count for each merchant
  const getOfferCount = (merchantId: number) => {
    return offers.filter(offer => offer.merchantId === merchantId).length;
  };

  const handleAddMerchant = () => {
    if (recordCount >= recordLimit) {
      setShowLimitModal(true);
    } else {
      setShowAddMerchantForm(true);
    }
  };

  const handleDeleteMerchant = (merchant: Merchant) => {
    setMerchantToDelete(merchant);
  };

  const confirmDelete = () => {
    if (merchantToDelete) {
      deleteMutation.mutate(merchantToDelete.id);
    }
  };

  return (
    <>
      <Card>
        <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <CardTitle>Merchants</CardTitle>
            <CardDescription>Manage all your merchant accounts.</CardDescription>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 mt-4 md:mt-0">
            <Button onClick={handleAddMerchant}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Merchant
            </Button>
            <Button variant="outline" onClick={() => setShowUploadModal(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Bulk Upload
            </Button>
            <Button 
              variant="outline" 
              onClick={() => downloadAsCSV(merchants, 'merchants')}
            >
              <Download className="mr-2 h-4 w-4" />
              Download CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-500">
              Error loading merchants: {(error as Error).message}
            </div>
          ) : merchants.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No merchants found. Add your first merchant to get started.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">ID</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Merchant</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Category</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Country</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Description</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Tags</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Email</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500 text-sm">Offers</th>
                    <th className="py-3 px-4 text-right font-medium text-gray-500 text-sm">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {merchants.map((merchant) => (
                    <tr key={merchant.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4 text-sm font-mono">{merchant.id}</td>
                      <td className="py-3 px-4 text-sm">
                        <div className="flex items-center space-x-3">
                          {merchant.logo ? (
                            <img 
                              src={merchant.logo} 
                              alt={merchant.name} 
                              className="h-8 w-8 rounded-full object-cover"
                            />
                          ) : (
                            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white">
                              {merchant.name.substring(0, 2).toUpperCase()}
                            </div>
                          )}
                          <span>{merchant.name}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600">{merchant.category || 'N/A'}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{merchant.country || 'N/A'}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <span>{merchant.description || 'N/A'}</span>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => setShowLimitModal(true)}
                            className="ml-2"
                          >
                            <Wand2 className="h-4 w-4" />
                            <span className="sr-only">Generate Description</span>
                          </Button>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <span>{merchant.tags || 'N/A'}</span>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => setShowLimitModal(true)}
                            className="ml-2"
                          >
                            <Wand2 className="h-4 w-4" />
                            <span className="sr-only">Generate Tags</span>
                          </Button>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-600">{merchant.email}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{getOfferCount(merchant.id)} offers</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex justify-end space-x-2">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => {
                              setMerchantToEdit(merchant);
                              setShowEditMerchantForm(true);
                            }}
                          >
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleDeleteMerchant(merchant)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Merchant Form */}
      <AddMerchantForm 
        open={showAddMerchantForm || showEditMerchantForm} 
        onOpenChange={(open) => {
          if (!open) {
            setShowAddMerchantForm(false);
            setShowEditMerchantForm(false);
            setMerchantToEdit(null);
          }
        }}
        editMerchant={merchantToEdit}
      />

      {/* CSV Upload Modal */}
      <CSVUploadModal
        open={showUploadModal}
        onOpenChange={setShowUploadModal}
      />

      {/* Limit Exceeded Modal */}
      <LimitExceededModal 
        open={showLimitModal}
        onOpenChange={setShowLimitModal}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!merchantToDelete} onOpenChange={(open) => !open && setMerchantToDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {merchantToDelete?.name}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMerchantToDelete(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteMutation.isPending}>
              {deleteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}