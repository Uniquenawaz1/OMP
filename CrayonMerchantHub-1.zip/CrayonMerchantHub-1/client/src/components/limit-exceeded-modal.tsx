
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";

interface LimitExceededModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function LimitExceededModal({ open, onOpenChange }: LimitExceededModalProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Subscribe to Pro Version</AlertDialogTitle>
          <AlertDialogDescription>
            This feature requires a Pro subscription. Upgrade to access AI-powered content generation for descriptions and tags.
            Contact our sales team to learn more about Pro features.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Close</AlertDialogCancel>
          <Button 
            className="bg-primary text-white hover:bg-primary/90"
            onClick={() => window.open('mailto:sales@crayondata.com')}
          >
            Contact Sales
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
