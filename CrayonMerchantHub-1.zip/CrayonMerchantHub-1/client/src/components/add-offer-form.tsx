import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Merchant } from "@shared/schema";
import { LimitExceededModal } from "@/components/limit-exceeded-modal";
import { useState } from "react";
import { Loader2 } from "lucide-react";

interface AddOfferFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  merchants: Merchant[];
}

const offerSchema = z.object({
  title: z.string().min(2, { message: "Title must be at least 2 characters" }),
  description: z.string().min(5, { message: "Description is required" }),
  merchantId: z.string().min(1, { message: "Please select a merchant" }),
  offerType: z.string().min(1, { message: "Offer type is required" }),
  channel: z.enum(["online", "offline", "both"], {
    errorMap: () => ({ message: "Please select a valid channel" })
  }),
  startDate: z.string().min(1, { message: "Start date is required" }),
  endDate: z.string().min(1, { message: "End date is required" }),
  terms: z.string().optional().nullable(),
  redemptionInstructions: z.string().optional().nullable(),
  locations: z.string().optional().nullable(),
  image: z.string().optional().nullable(),
}).refine((data) => {
  const startDate = new Date(data.startDate);
  const endDate = new Date(data.endDate);
  return endDate >= startDate;
}, {
  message: "End date must be after start date",
  path: ["endDate"],
});

type FormValues = z.infer<typeof offerSchema>;

export function AddOfferForm({ open, onOpenChange, merchants }: AddOfferFormProps) {
  const { toast } = useToast();
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(offerSchema),
    defaultValues: {
      title: "",
      description: "",
      merchantId: "",
      offerType: "discount",
      channel: "online", // Using a valid enum value
      terms: "",
      redemptionInstructions: "",
      locations: "",
      image: null,
      startDate: new Date().toISOString().split('T')[0], // Today
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Today + 30 days
    },
  });
  
  const addMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      // Convert dates to proper format
      const startDate = new Date(data.startDate);
      const endDate = new Date(data.endDate);
      
      // Prepare the offer data with proper types
      const offerData = {
        ...data,
        merchantId: parseInt(data.merchantId),
        startDate,
        endDate,
        status: "pending" as const, // This ensures it matches the expected type
        channel: data.channel as "online" | "offline" | "both", // This ensures it matches the expected type
        // Ensure required fields have default values
        terms: data.terms || "",
        redemptionInstructions: data.redemptionInstructions || "",
        locations: data.locations || "",
        image: data.image || null
      };
      
      const res = await apiRequest("POST", "/api/offers", offerData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/records/count'] });
      toast({
        title: "Offer added",
        description: "The offer has been added successfully.",
      });
      form.reset();
      onOpenChange(false);
    },
    onError: (error: any) => {
      // Check if this is a limit exceeded error
      if (error.message?.includes("403") && error.message?.includes("exceeded")) {
        setShowLimitModal(true);
      } else {
        toast({
          title: "Error",
          description: `Failed to add offer: ${error.message}`,
          variant: "destructive",
        });
      }
    },
  });
  
  function onSubmit(data: FormValues) {
    addMutation.mutate(data);
  }
  
  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[750px]">
          <DialogHeader>
            <DialogTitle>Add New Offer</DialogTitle>
            <DialogDescription>
              Enter the offer details below. Fields marked with * are required.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="overflow-auto max-h-[60vh] pr-1">
                {/* Basic Information */}
                <div className="mb-5 p-4 border rounded-md bg-slate-50">
                  <h3 className="text-sm font-medium mb-3 text-slate-700">Basic Information</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Offer Title*</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter offer title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="merchantId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Merchant*</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a merchant" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {merchants.length > 0 ? (
                                merchants.map((merchant) => (
                                  <SelectItem key={merchant.id} value={merchant.id.toString()}>
                                    {merchant.name}
                                  </SelectItem>
                                ))
                              ) : (
                                <SelectItem value="no-merchants" disabled>
                                  No merchants available
                                </SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                          {merchants.length === 0 && (
                            <FormDescription className="text-red-500">
                              Please add a merchant first before creating an offer.
                            </FormDescription>
                          )}
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="mt-4">
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description*</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Enter offer description" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                {/* Offer Details */}
                <div className="mb-5 p-4 border rounded-md bg-slate-50">
                  <h3 className="text-sm font-medium mb-3 text-slate-700">Offer Details</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="offerType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Offer Type*</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select offer type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="discount">Discount</SelectItem>
                              <SelectItem value="cashback">Cashback</SelectItem>
                              <SelectItem value="bogo">Buy One Get One</SelectItem>
                              <SelectItem value="gift">Gift with Purchase</SelectItem>
                              <SelectItem value="loyalty">Loyalty Points</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="channel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Offer Channel*</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select offer channel" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="online">Online</SelectItem>
                              <SelectItem value="offline">Offline</SelectItem>
                              <SelectItem value="both">Both (Online & Offline)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Date*</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Date*</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="mt-4">
                    <FormField
                      control={form.control}
                      name="locations"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Applicable Locations*</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter applicable locations" {...field} />
                          </FormControl>
                          <FormDescription>
                            Comma-separated list of locations where this offer is valid
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                {/* Terms and Redemption */}
                <div className="mb-5 p-4 border rounded-md bg-slate-50">
                  <h3 className="text-sm font-medium mb-3 text-slate-700">Terms and Redemption</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="terms"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Terms & Conditions*</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Enter terms and conditions" 
                              className="min-h-[100px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="redemptionInstructions"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>How to Redeem*</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Enter redemption instructions" 
                              className="min-h-[100px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                {/* Media */}
                <div className="mb-5 p-4 border rounded-md bg-slate-50">
                  <h3 className="text-sm font-medium mb-3 text-slate-700">Media</h3>
                  <div className="flex items-start space-x-4">
                    <div className="flex-1">
                      <FormField
                        control={form.control}
                        name="image"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-xs">Offer Image*</FormLabel>
                            <FormControl>
                              <Input 
                                type="file" 
                                accept="image/*" 
                                className="text-xs"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    // Convert to base64 for storage
                                    const reader = new FileReader();
                                    reader.onload = (event) => {
                                      field.onChange(event.target?.result as string);
                                    };
                                    reader.readAsDataURL(file);
                                  }
                                }}
                              />
                            </FormControl>
                            <FormDescription className="text-xs">
                              Upload an image that represents this offer (required)
                            </FormDescription>
                            <FormMessage className="text-xs" />
                          </FormItem>
                        )}
                      />
                    </div>
                    {form.watch("image") && (
                      <div className="w-32 h-32 border rounded flex-shrink-0 overflow-hidden">
                        <img 
                          src={form.watch("image")} 
                          alt="Preview" 
                          className="w-full h-full object-contain"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <DialogFooter>
                <div className="flex flex-col sm:flex-row w-full sm:w-auto space-y-2 sm:space-y-0 sm:space-x-2">
                  <Button variant="outline" onClick={() => onOpenChange(false)} type="button">
                    Cancel
                  </Button>
                  <Button 
                    variant="secondary" 
                    type="button" 
                    onClick={() => setShowPreview(true)}
                  >
                    Preview
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={addMutation.isPending || merchants.length === 0}
                  >
                    {addMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Add Offer
                  </Button>
                </div>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      <LimitExceededModal 
        open={showLimitModal}
        onOpenChange={setShowLimitModal}
      />
      
      {/* Offer Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="sm:max-w-[900px]">
          <DialogHeader>
            <DialogTitle>Offer Preview</DialogTitle>
            <DialogDescription>
              This is how your offer will appear to users on mobile and desktop.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-4">
            {/* Mobile Preview */}
            <div>
              <h3 className="text-sm font-medium mb-3">Mobile View</h3>
              <div className="border rounded-lg overflow-hidden w-[320px] mx-auto shadow-md">
                <div className="h-12 bg-primary flex items-center px-4">
                  <div className="text-white font-medium">Mobile App</div>
                </div>
                <div className="p-4 bg-white">
                  <div className="relative h-32 bg-gray-100 rounded-lg mb-3 overflow-hidden">
                    {form.watch("image") ? (
                      <img 
                        src={form.watch("image")} 
                        alt="Offer preview" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-gray-400">
                        No image uploaded
                      </div>
                    )}
                  </div>
                  <h3 className="font-bold text-lg mb-1">{form.watch("title") || "Offer Title"}</h3>
                  <p className="text-sm text-gray-600 mb-3">{form.watch("description") || "Offer description will appear here..."}</p>
                  <div className="text-xs text-gray-500 flex justify-between">
                    <span>Valid till: {form.watch("endDate") || "End date"}</span>
                    <span>{form.watch("offerType") || "Offer type"}</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Desktop Preview */}
            <div>
              <h3 className="text-sm font-medium mb-3">Desktop View</h3>
              <div className="border rounded-lg overflow-hidden shadow-md">
                <div className="h-12 bg-primary flex items-center px-4">
                  <div className="text-white font-medium">Website</div>
                </div>
                <div className="p-6 bg-white">
                  <div className="flex">
                    <div className="relative h-40 w-40 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                      {form.watch("image") ? (
                        <img 
                          src={form.watch("image")} 
                          alt="Offer preview" 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full text-gray-400">
                          No image uploaded
                        </div>
                      )}
                    </div>
                    <div className="ml-4 flex-1">
                      <h3 className="font-bold text-xl mb-2">{form.watch("title") || "Offer Title"}</h3>
                      <p className="text-sm text-gray-600 mb-3">{form.watch("description") || "Offer description will appear here..."}</p>
                      
                      <div className="text-sm">
                        <div className="mb-2">
                          <span className="font-medium">Offer Type:</span> {form.watch("offerType") || "Not specified"}
                        </div>
                        <div className="mb-2">
                          <span className="font-medium">Available:</span> {form.watch("channel") || "Not specified"}
                        </div>
                        <div className="mb-2">
                          <span className="font-medium">Valid:</span> {form.watch("startDate") || "Start date"} to {form.watch("endDate") || "End date"}
                        </div>
                        {form.watch("locations") && (
                          <div className="mb-2">
                            <span className="font-medium">Locations:</span> {form.watch("locations")}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {(form.watch("terms") || form.watch("redemptionInstructions")) && (
                    <div className="mt-4 pt-4 border-t">
                      {form.watch("redemptionInstructions") && (
                        <div className="mb-3">
                          <h4 className="font-medium mb-1">How to Redeem:</h4>
                          <p className="text-sm text-gray-600">{form.watch("redemptionInstructions")}</p>
                        </div>
                      )}
                      
                      {form.watch("terms") && (
                        <div>
                          <h4 className="font-medium mb-1">Terms & Conditions:</h4>
                          <p className="text-sm text-gray-600">{form.watch("terms")}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button onClick={() => setShowPreview(false)}>Close Preview</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
