import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { LimitExceededModal } from "@/components/limit-exceeded-modal";
import { useState } from "react";
import { Loader2 } from "lucide-react";

interface AddMerchantFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const merchantSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  category: z.string().min(2, { message: "Category is required" }),
  country: z.string().min(2, { message: "Country is required" }),
  registrationNumber: z.string().min(2, { message: "Registration number is required" }),
  logo: z.string().optional(),
  email: z.string().email({ message: "Invalid email address" }),
  phone: z.string().min(5, { message: "Phone number is required" }),
  address: z.string().min(5, { message: "Address is required" }),
});

type FormValues = z.infer<typeof merchantSchema>;

export function AddMerchantForm({ open, onOpenChange }: AddMerchantFormProps) {
  const { toast } = useToast();
  const [showLimitModal, setShowLimitModal] = useState(false);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(merchantSchema),
    defaultValues: {
      name: "",
      category: "",
      country: "",
      registrationNumber: "",
      logo: "",
      email: "",
      phone: "",
      address: "",
    },
  });
  
  const addMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const res = await apiRequest("POST", "/api/merchants", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/merchants'] });
      queryClient.invalidateQueries({ queryKey: ['/api/records/count'] });
      toast({
        title: "Merchant added",
        description: "The merchant has been added successfully.",
      });
      form.reset();
      onOpenChange(false);
    },
    onError: (error: any) => {
      // Check if this is a limit exceeded error
      if (error.message?.includes("403") && error.message?.includes("exceeded")) {
        setShowLimitModal(true);
      } else {
        toast({
          title: "Error",
          description: `Failed to add merchant: ${error.message}`,
          variant: "destructive",
        });
      }
    },
  });
  
  function onSubmit(data: FormValues) {
    addMutation.mutate(data);
  }
  
  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>Add New Merchant</DialogTitle>
            <DialogDescription>
              Enter the merchant details below. Fields marked with * are required.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="overflow-y-auto max-h-[60vh] pr-1">
              {/* Basic Information Section */}
              <div className="mb-5 p-4 border rounded-md bg-slate-50">
                <h3 className="text-sm font-medium mb-3 text-slate-700">Basic Information</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">Merchant Name*</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter merchant name" {...field} />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">Merchant Category*</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter merchant category" {...field} />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              {/* Registration Details Section */}
              <div className="mb-5 p-4 border rounded-md bg-slate-50">
                <h3 className="text-sm font-medium mb-3 text-slate-700">Registration Details</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">Registered Country*</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter country" {...field} />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="registrationNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">Registration Number*</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter registration number" {...field} />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              {/* Logo Section */}
              <div className="mb-5 p-4 border rounded-md bg-slate-50">
                <h3 className="text-sm font-medium mb-3 text-slate-700">Brand Identity</h3>
                <div className="flex items-start space-x-4">
                  <div className="flex-1">
                    <FormField
                      control={form.control}
                      name="logo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs">Merchant Logo*</FormLabel>
                          <FormControl>
                            <Input 
                              type="file" 
                              accept="image/*" 
                              className="text-xs"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  // Convert to base64 for storage
                                  const reader = new FileReader();
                                  reader.onload = (event) => {
                                    field.onChange(event.target?.result as string);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </FormControl>
                          <FormMessage className="text-xs" />
                        </FormItem>
                      )}
                    />
                  </div>
                  {form.watch("logo") && (
                    <div className="w-16 h-16 border rounded flex-shrink-0 overflow-hidden">
                      <img 
                        src={form.watch("logo")} 
                        alt="Preview" 
                        className="w-full h-full object-contain"
                      />
                    </div>
                  )}
                </div>
              </div>
              
              {/* Contact Information Section */}
              <div className="mb-5 p-4 border rounded-md bg-slate-50">
                <h3 className="text-sm font-medium mb-3 text-slate-700">Contact Information</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">Email*</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="Enter email" {...field} />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">Phone*</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter phone number" {...field} />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="mt-4">
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs">Address*</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Enter merchant address" className="resize-none" {...field} />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => onOpenChange(false)} type="button">
                  Cancel
                </Button>
                <Button type="submit" disabled={addMutation.isPending}>
                  {addMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Add Merchant
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      <LimitExceededModal 
        open={showLimitModal}
        onOpenChange={setShowLimitModal}
      />
    </>
  );
}
