import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { getInitials } from "@/lib/utils";
import { useState } from "react";
import { Logo } from "@/components/logo";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { LogOut, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

interface NavbarProps {
  activeTab: 'dashboard' | 'merchants' | 'offers';
  onTabChange: (tab: 'dashboard' | 'merchants' | 'offers') => void;
  recordCount: number;
  recordLimit: number;
}

export function Navbar({ activeTab, onTabChange, recordCount, recordLimit }: NavbarProps) {
  const { user, logoutMutation } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const tabClass = (tab: string) => {
    return tab === activeTab
      ? "px-3 py-2 rounded-md text-sm font-medium text-white bg-primary"
      : "px-3 py-2 rounded-md text-sm font-medium text-gray-500 hover:text-gray-700";
  };
  
  const mobileTabClass = (tab: string) => {
    return tab === activeTab
      ? "block px-3 py-2 rounded-md text-base font-medium text-white bg-primary"
      : "block px-3 py-2 rounded-md text-base font-medium text-gray-500 hover:text-gray-700";
  };
  
  return (
    <header className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Logo className="h-8 w-auto" />
            </div>
            <div className="hidden md:ml-10 md:flex items-baseline space-x-4">
              <button 
                className={tabClass('dashboard')} 
                onClick={() => onTabChange('dashboard')}
              >
                Dashboard
              </button>
              <button 
                className={tabClass('merchants')} 
                onClick={() => onTabChange('merchants')}
              >
                Merchants
              </button>
              <button 
                className={tabClass('offers')} 
                onClick={() => onTabChange('offers')}
              >
                Offers
              </button>
            </div>
          </div>
          
          <div className="flex items-center">
            <span className="text-sm text-gray-600 mr-4 hidden sm:block">
              Records: <span className="font-bold">{recordCount}</span>/{recordLimit}
            </span>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8 bg-primary">
                    <AvatarFallback>{user ? getInitials(user.username) : "?"}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem disabled>
                  Signed in as <span className="font-bold ml-1">{user?.username}</span>
                </DropdownMenuItem>
                <DropdownMenuItem disabled>
                  Role: <span className="font-bold ml-1 capitalize">{user?.role}</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {/* Mobile menu */}
            <div className="md:hidden ml-4">
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6" />
                    <span className="sr-only">Open menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="left">
                  <SheetHeader>
                    <SheetTitle>
                      <Logo className="h-8 w-auto mx-auto" />
                    </SheetTitle>
                  </SheetHeader>
                  <div className="py-6 space-y-2">
                    <button 
                      className={mobileTabClass('dashboard')} 
                      onClick={() => {
                        onTabChange('dashboard');
                        setIsMobileMenuOpen(false);
                      }}
                    >
                      Dashboard
                    </button>
                    <button 
                      className={mobileTabClass('merchants')} 
                      onClick={() => {
                        onTabChange('merchants');
                        setIsMobileMenuOpen(false);
                      }}
                    >
                      Merchants
                    </button>
                    <button 
                      className={mobileTabClass('offers')} 
                      onClick={() => {
                        onTabChange('offers');
                        setIsMobileMenuOpen(false);
                      }}
                    >
                      Offers
                    </button>
                    
                    <div className="pt-4 mt-4 border-t border-gray-200">
                      <div className="px-3 py-2">
                        <span className="text-sm text-gray-600">
                          Records: <span className="font-bold">{recordCount}</span>/{recordLimit}
                        </span>
                      </div>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start px-3"
                        onClick={handleLogout}
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>Log out</span>
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
