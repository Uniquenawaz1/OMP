import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Upload, HelpCircle, Loader2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { LimitExceededModal } from "@/components/limit-exceeded-modal";
import { parseCSV, downloadTemplate } from "@/lib/utils";

interface CSVUploadModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CSVUploadModal({ open, onOpenChange }: CSVUploadModalProps) {
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [uploadType, setUploadType] = useState<"merchants" | "offers">("merchants");
  const [error, setError] = useState<string | null>(null);
  const [showLimitModal, setShowLimitModal] = useState(false);
  
  const uploadMutation = useMutation({
    mutationFn: async (data: any[]) => {
      const res = await apiRequest("POST", `/api/bulk/${uploadType}`, data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/${uploadType}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/records/count'] });
      toast({
        title: "Upload successful",
        description: `Successfully uploaded ${data.length} ${uploadType}`,
      });
      resetForm();
      onOpenChange(false);
    },
    onError: (error: any) => {
      // Check if this is a limit exceeded error
      if (error.message?.includes("403") && error.message?.includes("exceeded")) {
        setShowLimitModal(true);
      } else {
        toast({
          title: "Upload failed",
          description: error.message,
          variant: "destructive",
        });
      }
    },
  });
  
  const resetForm = () => {
    setFile(null);
    setError(null);
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const selectedFile = e.target.files?.[0];
    
    if (!selectedFile) {
      return;
    }
    
    // Check file type
    if (!selectedFile.name.endsWith('.csv')) {
      setError("Please upload a CSV file");
      return;
    }
    
    // Check file size (10MB limit)
    if (selectedFile.size > 10 * 1024 * 1024) {
      setError("File size exceeds 10MB limit");
      return;
    }
    
    setFile(selectedFile);
  };
  
  const handleSubmit = async () => {
    if (!file) {
      setError("Please select a file to upload");
      return;
    }
    
    try {
      const parsedData = await parseCSV(file);
      
      if (parsedData.length === 0) {
        setError("The CSV file doesn't contain any valid data");
        return;
      }
      
      // Basic validation
      if (uploadType === "merchants") {
        if (!parsedData[0].hasOwnProperty('name') || 
            !parsedData[0].hasOwnProperty('email') || 
            !parsedData[0].hasOwnProperty('phone') || 
            !parsedData[0].hasOwnProperty('address')) {
          setError("CSV format is invalid. Please use the template provided.");
          return;
        }
      } else {
        if (!parsedData[0].hasOwnProperty('title') || 
            !parsedData[0].hasOwnProperty('description') || 
            !parsedData[0].hasOwnProperty('startDate') || 
            !parsedData[0].hasOwnProperty('endDate') || 
            !parsedData[0].hasOwnProperty('merchantId')) {
          setError("CSV format is invalid. Please use the template provided.");
          return;
        }
      }
      
      uploadMutation.mutate(parsedData);
    } catch (err) {
      setError(`Error parsing CSV: ${(err as Error).message}`);
    }
  };
  
  const handleDownloadTemplate = (type: "merchants" | "offers") => {
    downloadTemplate(type);
  };
  
  return (
    <>
      <Dialog open={open} onOpenChange={(isOpen) => {
        if (!isOpen) resetForm();
        onOpenChange(isOpen);
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Bulk Upload</DialogTitle>
            <DialogDescription>
              Upload a CSV file to add multiple {uploadType} at once.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-2">
              <Label>Upload Type</Label>
              <RadioGroup 
                value={uploadType} 
                onValueChange={(value) => setUploadType(value as "merchants" | "offers")}
                className="flex space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="merchants" id="merchants" />
                  <Label htmlFor="merchants">Merchants</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="offers" id="offers" />
                  <Label htmlFor="offers">Offers</Label>
                </div>
              </RadioGroup>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Label>CSV File</Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-gray-400" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p>Upload a CSV file with the following columns:</p>
                      {uploadType === "merchants" ? (
                        <p className="text-xs">name, email, phone, address</p>
                      ) : (
                        <p className="text-xs">title, description, startDate, endDate, merchantId</p>
                      )}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              
              <div className="flex items-center justify-center w-full">
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload className="w-8 h-8 mb-2 text-gray-500" />
                    <p className="mb-2 text-sm text-gray-500">
                      <span className="font-semibold">Click to upload</span> or drag and drop
                    </p>
                    <p className="text-xs text-gray-500">CSV (max 10MB)</p>
                  </div>
                  <input 
                    type="file" 
                    className="hidden" 
                    accept=".csv" 
                    onChange={handleFileChange} 
                  />
                </label>
              </div>
              
              {file && (
                <p className="text-sm text-gray-500">
                  Selected file: {file.name} ({(file.size / 1024).toFixed(2)} KB)
                </p>
              )}
            </div>
            
            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-blue-400" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-blue-700">
                    Download template files: 
                    <button 
                      className="ml-1 font-medium underline text-blue-700 hover:text-blue-600"
                      onClick={() => handleDownloadTemplate("merchants")}
                    >
                      Merchants
                    </button> | 
                    <button 
                      className="ml-1 font-medium underline text-blue-700 hover:text-blue-600"
                      onClick={() => handleDownloadTemplate("offers")}
                    >
                      Offers
                    </button>
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              onClick={handleSubmit} 
              disabled={!file || uploadMutation.isPending}
            >
              {uploadMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <LimitExceededModal 
        open={showLimitModal}
        onOpenChange={setShowLimitModal}
      />
    </>
  );
}
