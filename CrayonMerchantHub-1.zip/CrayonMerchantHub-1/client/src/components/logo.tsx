import React from "react";

interface LogoProps {
  className?: string;
}

export function Logo({ className }: LogoProps) {
  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <svg 
        width="30" 
        height="30" 
        viewBox="0 0 512 512" 
        className="text-primary" 
        fill="currentColor"
      >
        <path d="M256 0C114.6 0 0 114.6 0 256s114.6 256 256 256 256-114.6 256-256S397.4 0 256 0zm0 464c-114.7 0-208-93.3-208-208S141.3 48 256 48s208 93.3 208 208-93.3 208-208 208z"/>
        <path d="M325.8 186.2c-22.9-22.9-59.9-22.9-82.8 0-16.3 16.3-21 40.2-14.3 60.9l-67.4 67.4c-6.2 6.2-6.2 16.4 0 22.6 6.2 6.2 16.4 6.2 22.6 0l67.4-67.4c20.7 6.7 44.6 2 60.9-14.3 22.9-22.8 22.9-59.8 0-82.8zm-41.4 63.3c-12.1 0-22-9.9-22-22s9.9-22 22-22 22 9.9 22 22-9.9 22-22 22z"/>
        <path d="M398.5 146.5c-8.2-8.2-21.5-8.2-29.7 0L184.9 330.4c-8.2 8.2-8.2 21.5 0 29.7 8.2 8.2 21.5 8.2 29.7 0l183.9-183.9c8.2-8.2 8.2-21.5 0-29.7z"/>
      </svg>
      <span className="text-xl font-bold text-gray-800">Crayon Data</span>
    </div>
  );
}
