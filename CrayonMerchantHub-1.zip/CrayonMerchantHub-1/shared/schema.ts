import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().$type<"merchant" | "bank">(),
});

export const merchants = pgTable("merchants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  country: text("country").notNull(),
  registrationNumber: text("registration_number").notNull(),
  logo: text("logo"),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  description: text("description"),
  tags: text("tags"),
  userId: integer("user_id").references(() => users.id),
});

export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  terms: text("terms"),
  redemptionInstructions: text("redemption_instructions"),
  offerType: text("offer_type").notNull(),
  channel: text("channel").notNull().$type<"online" | "offline" | "both">(),
  locations: text("locations"),
  image: text("image"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").notNull().$type<"active" | "pending" | "live" | "expired">(),
  merchantId: integer("merchant_id").references(() => merchants.id),
  userId: integer("user_id").references(() => users.id),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  role: true,
});

export const insertMerchantSchema = z.object({
  name: z.string(),
  email: z.string().email(),
  phone: z.string(),
  address: z.string(),
  category: z.string().optional(),
  country: z.string().optional(),
  registrationNumber: z.string().optional(),
  logo: z.string().optional(),
  userId: z.number().optional(),
});

export const insertOfferSchema = z.object({
  title: z.string(),
  description: z.string(),
  terms: z.string().optional().nullable(),
  redemptionInstructions: z.string().optional().nullable(),
  offerType: z.string(),
  channel: z.enum(["online", "offline", "both"]),
  locations: z.string().optional().nullable(),
  image: z.string().optional().nullable(),
  startDate: z.string().transform(str => new Date(str)),
  endDate: z.string().transform(str => new Date(str)),
  status: z.enum(["active", "pending", "expired"]),
  merchantId: z.number(),
  userId: z.number().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertMerchant = z.infer<typeof insertMerchantSchema>;
export type Merchant = typeof merchants.$inferSelect;

export type InsertOffer = z.infer<typeof insertOfferSchema>;
export type Offer = typeof offers.$inferSelect;